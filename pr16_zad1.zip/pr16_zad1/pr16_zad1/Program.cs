﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace pr16_zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите название файла (file1.txt)");
            string file = Console.ReadLine();
            if (File.Exists(file))
            {
                string[] text = File.ReadAllLines("file1.txt");
                Console.Write("Текст:");
                foreach (var t in text)
                Console.WriteLine(t);
                string poisk = "";
                bool a = false;
                do
                {
                    Console.WriteLine("Введите слово");
                    poisk = Console.ReadLine();
                    a = poisk.All(char.IsLetter);
                } while (a == false);
                if (a == true)
                {

                    int count = text.SelectMany(text1 => text1.Split(new char[] { ' ', '.', ',', '!', '?', ':', ';' },
                        StringSplitOptions.RemoveEmptyEntries)).Where(r => r.ToLower() == poisk.ToLower()).Count();
                    Console.WriteLine($"были найдены {count} вхождения (ий) поискового запроса ({poisk})");
                }
                else Console.WriteLine("Такое слово не найдено");
            }
            else Console.WriteLine("Файл не существует");
            Console.ReadKey();
        }
    }
}

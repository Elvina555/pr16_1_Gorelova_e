﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace pr16_zad2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] mass = textBox1.Text.Split(' ');
            bool slash = mass.Any(m => m.Contains("/"));
            if (textBox1.Text != "")
            {
                if (slash == true)
                {
                    var a1 = mass.SelectMany(x => x).Count(char.IsDigit);
                    textBox2.Text = $"{a1}";
                    if (File.Exists("file.txt"))
                    {
                        using (StreamWriter sw = new StreamWriter("file.txt"))
                        {
                            var a2 = mass.TakeWhile(x => x != "/").ToList();
                            foreach (var el in a2)
                            {
                                textBox3.Text += $"{el} ";
                                sw.Write($"{el} ");
                            }
                            var a3 = mass.SkipWhile(m => m != "/").Skip(1).
                            Select(m => string.Concat(m.Select(m1 => char.IsUpper(m1) ? char.ToLower(m1) : char.ToUpper(m1))))
                            .ToArray();
                            foreach (var element in a3)
                            {
                                textBox4.Text += $"{element} ";
                                sw.Write($"{element} ");
                            }
                        }
                    }
                    else MessageBox.Show("Файл не найден");
                }
                else MessageBox.Show("В строке отсутствует элемент '/' ");
            }
            else MessageBox.Show("Заполните строку");
        }
    }
}
